<!DOCTYPE html>
<html class="no-js" lang="">
<head>
        <?php include('components/meta_en.php') ?>
    </head>
    <body class="sticky-header">
        <?php include('components/header_en.php') ?>


        <?php include('main_content/' . $main_content . '.php') ?>


        <?php include('components/footer_en.php') ?>
    </body>
</html>
