<style>
    .form-group input {
        height: 40px;
    }
    .nav-tabs .nav-item {
        color: #fff;
    }

</style>
<section id="tabs" class="section-padding-2-10 project-tab">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <ul id="breadcrumb">
                    <li><a href="?page=index" class="active"><i class="fa fa-home"> </i></a></li>
                    <li><a href="?page=login" class="active"> سجل بياناتك</a></li>
                    <li><a href="?page=nationality" class="active"> اختر الجنسية</a></li>
                    <li><a href="?page=team"> اختر العاملة المنزلية</a></li>
                    <li><a href="?page=pay">تفاصيل الطلب / الدفع</a></li>
                </ul>
            </div>
            </div>




        <div class="row bggred marg0 padd4040040">
            <div class="col-lg-12">
                <div class="heading-layout4"> <h4 class="colorwh">الرجاء اختيار الجنسية المناسبة لك</h4> </div>

            </div>
            <div class="col-md-4">
                <form class="form-inline pr20">

                    <label class="colorwh" style="width: 100%;text-align: right;display: inline-block;font-size: 10px"> هل لديك رمز ترويجي؟</label>

                    <div class="form-group mx-sm-3 mb-2" style="margin-right:0px !important;">
                         <input type="text" class="form-control" id="inputPassword2" placeholder=" " style="width: 130px; height: 30px;">
                    </div>
                    <button type="submit" class="btn fw-btn-fill btn-success  mb-2" style="width: auto;padding: 4px;">تأكيد</button>
                </form>

                <img src="img/figure/banner-figure.png" alt="figure" class="ser_wom">

            </div>
            <div class="col-md-8 single-product-other-info">
                <ul class="nav nav-tabs tab-nav-list">
                    <li class="nav-item">
                        <a class="active" href="#nav-home" data-toggle="tab" aria-expanded="false">3 شهور</a>
                    </li>
                    <li class="nav-item">
                        <a href="#nav-profile" data-toggle="tab" aria-expanded="false">6 شهور</a>
                    </li>
                    <li class="nav-item">
                        <a href="#nav-contact" data-toggle="tab" aria-expanded="false">12 شهر</a>
                    </li>
                    <li class="nav-item">
                        <a href="#nav-contact2" data-toggle="tab" aria-expanded="false">24 شهر</a>
                    </li>
                </ul>



    <!--            <nav>
                    <div class="nav nav-tabs tab-nav-list" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">3 شهور</a>
                        <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">6 شهور</a>
                        <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">12 شهور</a>
                        <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact2" aria-selected="false">24 شهور</a>
                    </div>
                </nav>-->
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div id="product-view" class="product-box-grid">

                            <div class="row">
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/ben.png" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="?page=team" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="?page=team">بنجلاديش</a></h4>
                                                دفعة شهرية

                                                <div class="item-price">

                                                    1850  ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>



                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                        <div id="product-view" class="product-box-grid">
                            <div class="row">
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/ben.png" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <!--<a href="#"onclick="window.open('?page=team','name','width=1200,height=600')">Popup link</a>-->
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">بنجلاديش</a></h4>
                                                دفعة شهرية

                                                <div class="item-price">

                                                    1850  ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                        <div id="product-view" class="product-box-grid">
                            <div class="row">
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/ben.png" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">بنجلاديش</a></h4>
                                                دفعة شهرية

                                                <div class="item-price">

                                                    1850  ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/Flag-Indonesia.jpg" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">إندونيسيا</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    2300 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/uganda .png" alt="uganda ">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">اوغندا</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    1850 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/Cameroon.png" alt="Cameroon">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">كاميرون</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    2300 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/ben.png" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">بنجلاديش</a></h4>
                                                دفعة شهرية

                                                <div class="item-price">

                                                    1850  ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/Flag-Indonesia.jpg" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">إندونيسيا</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    2300 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/uganda .png" alt="uganda ">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">اوغندا</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    1850 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/Cameroon.png" alt="Cameroon">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">كاميرون</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    2300 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-contact2" role="tabpanel" aria-labelledby="nav-contact-tab">
                        <div id="product-view" class="product-box-grid">
                            <div class="row">
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/ben.png" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">بنجلاديش</a></h4>
                                                دفعة شهرية

                                                <div class="item-price">

                                                    1850  ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/Flag-Indonesia.jpg" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">إندونيسيا</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    2300 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/uganda .png" alt="uganda ">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">اوغندا</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    1850 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/Cameroon.png" alt="Cameroon">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">كاميرون</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    2300 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/ben.png" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">بنجلاديش</a></h4>
                                                دفعة شهرية

                                                <div class="item-price">

                                                    1850  ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/Flag-Indonesia.jpg" alt="ben">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">إندونيسيا</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    2300 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/uganda .png" alt="uganda ">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">اوغندا</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    1850 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 col-12">
                                    <div class="product-box-layout1">
                                        <div class="product-grid-view">
                                            <div class="item-img">
                                                <img src="img/flag/Cameroon.png" alt="Cameroon">
                                                <div class="action-btn-area">
                                                    <ul>
                                                        <li><a href="#" class="cart-btn"><i class="fas fa-check-circle"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="item-content">

                                                <h4 class="item-title"><a href="#">كاميرون</a></h4>
                                                دفعة شهرية
                                                <div class="item-price">

                                                    2300 ر.س</div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Blog Area End Here -->