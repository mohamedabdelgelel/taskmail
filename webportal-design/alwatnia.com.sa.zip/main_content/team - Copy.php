
<!-- Blog Area Start Here -->

<section id="tabs" class="section-padding-2-10 project-tab">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <ul id="breadcrumb">
                    <li><a href="?page=index"><i class="fa fa-home"> </i></a></li>
                    <li><a href="?page=login"> سجل بياناتك</a></li>
                    <li><a href="?page=nationality" > اختر الجنسية</a></li>
                    <li><a href="?page=team" class="active"> اختر العاملة المنزلية</a></li>
                    <li><a href="#"> تفاصيل الطلب/ الدفع</a></li>
                    <!--<li><a href="#"><span class="icon icon-arrow-down"> </span> Download</a></li>-->
                </ul>
            </div>
        </div>
        <div class="row workerProfile_che bggred">

            <div class="col-lg-6 col-md-6 col-12">


                <ul class="list-unstyled">
                    <li class="media">
                        <div class="float-right">
                            <h5 class="mt-0 mb-1">Warda Helmy </h5>

                            <img src="img/team/1.jpg" class="mr-3" alt="..." style="">
                            <div class="form-check">
                                <input class="form-check-input position-static" type="radio" name="blankRadio" id="blankRadio1" value="option1" aria-label="...">
                            </div>
                        </div>

                        <div class="media-body">
                            <h5 class="mt-0 mb-1">الملف الشخصى</h5>
                            <table style="width:100%" cellpadding="0" cellspacing="0" >
                                <tbody>
                                <tr>
                                    <td>
                                        <ul class="workerProfile">
                                            <li> <i class="fas fa-asterisk"></i> متوقع فترة الانتظار للتسليم : 2 يوم </li>
                                            <li> <i class="fas fa-asterisk"></i> الديانة : مسلم</li>
                                            <li> <i class="fas fa-asterisk"></i> العمر : 44</li>
                                            <li> <i class="fas fa-asterisk"></i>  الحالة الاجتماعية : متزوجة</li>
                                            <li> <i class="fas fa-asterisk"></i> عدد الاطفال : 3</li>
                                            <li> <i class="fas fa-asterisk"></i>  المستوي التعليمي : ثانوي / إبتدائي</li>
                                            <li><i class="fas fa-asterisk"></i>  اللغة : بعثة اندونسيا</li>
                                        </ul>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </li>
                    <li class="media my-4">
                        <div class="float-right">
                            <h5 class="mt-0 mb-1">Warda Helmy </h5>

                            <img src="img/team/2.jpg" class="mr-3" alt="..." style="">
                            <div class="form-check">
                                <input class="form-check-input position-static" type="radio" name="blankRadio" id="blankRadio1" value="option1" aria-label="...">
                            </div>
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 mb-1">الملف الشخصى
                            </h5>
                            <table style="width:100%" cellpadding="0" cellspacing="0" >
                                <tbody>
                                <tr>
                                    <td>
                                        <ul class="workerProfile">
                                            <li> <i class="fas fa-asterisk"></i> متوقع فترة الانتظار للتسليم : 2 يوم </li>
                                            <li> <i class="fas fa-asterisk"></i> الديانة : مسلم</li>
                                            <li> <i class="fas fa-asterisk"></i> العمر : 44</li>
                                            <li> <i class="fas fa-asterisk"></i>  الحالة الاجتماعية : متزوجة</li>
                                            <li> <i class="fas fa-asterisk"></i> عدد الاطفال : 3</li>
                                            <li> <i class="fas fa-asterisk"></i>  المستوي التعليمي : ثانوي / إبتدائي</li>
                                            <li><i class="fas fa-asterisk"></i>  اللغة : بعثة اندونسيا</li>
                                        </ul>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </li>
                    <li class="media">
                        <div class="float-right">
                            <h5 class="mt-0 mb-1">Warda Helmy </h5>

                            <img src="img/team/3.jpg" class="mr-3" alt="..." style="">
                            <div class="form-check">
                                <input class="form-check-input position-static" type="radio" name="blankRadio" id="blankRadio1" value="option1" aria-label="...">
                            </div>
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 mb-1">الملف الشخصى
                            </h5>
                            <table style="width:100%" cellpadding="0" cellspacing="0" >
                                <tbody>
                                <tr>
                                    <td>
                                        <ul class="workerProfile">
                                            <li> <i class="fas fa-asterisk"></i> متوقع فترة الانتظار للتسليم : 2 يوم </li>
                                            <li> <i class="fas fa-asterisk"></i> الديانة : مسلم</li>
                                            <li> <i class="fas fa-asterisk"></i> العمر : 44</li>
                                            <li> <i class="fas fa-asterisk"></i>  الحالة الاجتماعية : متزوجة</li>
                                            <li> <i class="fas fa-asterisk"></i> عدد الاطفال : 3</li>
                                            <li> <i class="fas fa-asterisk"></i>  المستوي التعليمي : ثانوي / إبتدائي</li>
                                            <li><i class="fas fa-asterisk"></i>  اللغة : بعثة اندونسيا</li>
                                        </ul>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </li>
                </ul>

            </div>
            <div class="col-lg-6 col-md-6 col-12">


                <ul class="list-unstyled">
                    <li class="media">
                        <div class="float-right">
                            <h5 class="mt-0 mb-1">Warda Helmy </h5>

                            <img src="img/team/2.jpg" class="mr-3" alt="..." style="">
                            <div class="form-check">
                                <input class="form-check-input position-static" type="radio" name="blankRadio" id="blankRadio1" value="option1" aria-label="...">
                            </div>
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 mb-1">الملف الشخصى
                            </h5>
                            <table style="width:100%" cellpadding="0" cellspacing="0" >
                                <tbody>
                                <tr>
                                    <td>
                                        <ul class="workerProfile">
                                            <li> <i class="fas fa-asterisk"></i> متوقع فترة الانتظار للتسليم : 2 يوم </li>
                                            <li> <i class="fas fa-asterisk"></i> الديانة : مسلم</li>
                                            <li> <i class="fas fa-asterisk"></i> العمر : 44</li>
                                            <li> <i class="fas fa-asterisk"></i>  الحالة الاجتماعية : متزوجة</li>
                                            <li> <i class="fas fa-asterisk"></i> عدد الاطفال : 3</li>
                                            <li> <i class="fas fa-asterisk"></i>  المستوي التعليمي : ثانوي / إبتدائي</li>
                                            <li><i class="fas fa-asterisk"></i>  اللغة : بعثة اندونسيا</li>
                                        </ul>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </li>
                    <li class="media my-4">
                        <div class="float-right">
                            <h5 class="mt-0 mb-1">Warda Helmy </h5>

                            <img src="img/team/2.jpg" class="mr-3" alt="..." style="">
                            <div class="form-check">
                                <input class="form-check-input position-static" type="radio" name="blankRadio" id="blankRadio1" value="option1" aria-label="...">
                            </div>
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 mb-1">الملف الشخصى
                            </h5>
                            <table style="width:100%" cellpadding="0" cellspacing="0" >
                                <tbody>
                                <tr>
                                    <td>
                                        <ul class="workerProfile">
                                            <li> <i class="fas fa-asterisk"></i> متوقع فترة الانتظار للتسليم : 2 يوم </li>
                                            <li> <i class="fas fa-asterisk"></i> الديانة : مسلم</li>
                                            <li> <i class="fas fa-asterisk"></i> العمر : 44</li>
                                            <li> <i class="fas fa-asterisk"></i>  الحالة الاجتماعية : متزوجة</li>
                                            <li> <i class="fas fa-asterisk"></i> عدد الاطفال : 3</li>
                                            <li> <i class="fas fa-asterisk"></i>  المستوي التعليمي : ثانوي / إبتدائي</li>
                                            <li><i class="fas fa-asterisk"></i>  اللغة : بعثة اندونسيا</li>
                                        </ul>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </li>
                    <li class="media">
                        <div class="float-right">
                            <h5 class="mt-0 mb-1">Warda Helmy </h5>

                            <img src="img/team/2.jpg" class="mr-3" alt="..." style="">
                            <div class="form-check">
                                <input class="form-check-input position-static" type="radio" name="blankRadio" id="blankRadio1" value="option1" aria-label="...">
                            </div>
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 mb-1">الملف الشخصى
                            </h5>
                            <table style="width:100%" cellpadding="0" cellspacing="0" >
                                <tbody>
                                <tr>
                                    <td>
                                        <ul class="workerProfile">
                                            <li> <i class="fas fa-asterisk"></i> متوقع فترة الانتظار للتسليم : 2 يوم </li>
                                            <li> <i class="fas fa-asterisk"></i> الديانة : مسلم</li>
                                            <li> <i class="fas fa-asterisk"></i> العمر : 44</li>
                                            <li> <i class="fas fa-asterisk"></i>  الحالة الاجتماعية : متزوجة</li>
                                            <li> <i class="fas fa-asterisk"></i> عدد الاطفال : 3</li>
                                            <li> <i class="fas fa-asterisk"></i>  المستوي التعليمي : ثانوي / إبتدائي</li>
                                            <li><i class="fas fa-asterisk"></i>  اللغة : بعثة اندونسيا</li>
                                        </ul>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </li>
                </ul>

            </div>
        </div>
            <div class="row">
            <div class="col-2 mg-t-15"></div>
            <div class="col-4 mg-t-15 form-group">
                <button style="color: #821d26;background: #FFF;" type="submit" class="fw-btn-fill text-primarytext" value="?page=nationality">تأكيد</button>
            </div>
            <div class="col-4 mg-t-15 form-group">
                <button style="color: #821d26;background: #FFF;" type="submit" class="fw-btn-fill text-primarytext" value="?page=nationality">الرجوع الى الصفحة السابقة</button>
            </div>
            </div>

        </div>
     <!--   <div class="row">
            <div class="col-lg-3 col-md-6 col-12">
                <div class="team-box-layout2">
                    <a href="#" data-toggle="modal" data-target="#exampleModal">
                        <div class="item-img">
                            <img src="img/team/1.jpg" alt="team-member">
                            <div class="item-content">
                                <h3 class="item-title">ايي نور حياتي بت اويو مارناسه</h3>
                                <div class="item-subtitle"> متوقع فترة الانتظار للتسليم : 2 يوم</div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="team-box-layout2">
                    <a href="#" data-toggle="modal" data-target="#exampleModal">
                        <div class="item-img">
                            <img src="img/team/2.jpg" alt="team-member">
                            <div class="item-content">
                                <h3 class="item-title">هورنيواتي تانغال باسار</h3>
                                <div class="item-subtitle"> متوقع فترة الانتظار للتسليم : 2 يوم
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="team-box-layout2">
                    <a href="#" data-toggle="modal" data-target="#exampleModal">
                        <div class="item-img">
                            <img src="img/team/3.jpg" alt="team-member">
                            <div class="item-content">
                                <h3 class="item-title"><a href="#">ايجه بي تي ماسين</a></h3>
                                <div class="item-subtitle"> متوقع فترة الانتظار للتسليم : 2 يوم</div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="team-box-layout2">
                    <a href="#" data-toggle="modal" data-target="#exampleModal">
                        <div class="item-img">
                            <img src="img/team/1.jpg" alt="team-member">
                            <div class="item-content">
                                <h3 class="item-title">ايي نور
                                    حياتي بت اويو مارناسه</h3>
                                <div class="item-subtitle"> متوقع فترة الانتظار للتسليم : 2 يوم</div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

        </div>-->

    </div>
</section>
<!-- Blog Area End Here -->

<!-- Modal -->
<!--<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">الملف الشخصي
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table id="dlistAvailableWorkers_ctl00_tblIndividualWorker" class="csstblIndividualWorker_Normal"
                       style="width:100%" cellpadding="0" cellspacing="0" >
                    <tbody>
                    <tr>
                        <td>
                            <ul class="workerProfile">
                                <li> متوقع فترة الانتظار للتسليم : <span
                                            id="dlistAvailableWorkers_ctl00_lblWaitingDuration"
                                            style="background-color:Transparent;">2</span> <span
                                            id="dlistAvailableWorkers_ctl00_lblDays"
                                            style="display:inline-block;width:50px;">يوم</span></li>
                                <li> الديانة : مسلم</li>
                                <li> العمر : 44</li>
                                <li> الحالة الاجتماعية : متزوجة</li>
                                <li> عدد الاطفال : 3</li>
                                <li> المستوي التعليمي : ثانوي / إبتدائي</li>
                                <li> اللغة : بعثة اندونسيا</li>
                            </ul>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div style="display:inline-block; width:100%; position:relative; overflow:hidden">
                                <div id="dlistAvailableWorkers_ctl00_rg_WorkerExperience"
                                     class="RadGrid RadGrid_Sunset holdtablelist RadGridRTL RadGridRTL_Sunset"
                                     tabindex="0">
                                    <table class="rgMasterTable" border="0"
                                           id="dlistAvailableWorkers_ctl00_rg_WorkerExperience_ctl00"
                                           style="width:100%;table-layout:auto;empty-cells:show;text-align: right;">
                                        <colgroup>
                                            <col>
                                            <col>
                                            <col>
                                            <col>
                                        </colgroup>
                                        <thead>
                                        <tr>
                                            <th scope="col" class="rgHeader" style="background-color:LightBlue;">
                                                الدولة
                                            </th>
                                            <th scope="col" class="rgHeader" style="background-color:LightBlue;">
                                                الوظيفة
                                            </th>
                                            <th scope="col" class="rgHeader" style="background-color:LightBlue;">من</th>
                                            <th scope="col" class="rgHeader" style="background-color:LightBlue;">الي
                                            </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr class="rgRow" id="dlistAvailableWorkers_ctl00_rg_WorkerExperience_ctl00__0">
                                            <td>السعودية</td>
                                            <td>عاملة نظافة</td>
                                            <td>24/06/2010</td>
                                            <td>24/06/2012</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <input id="dlistAvailableWorkers_ctl00_rg_WorkerExperience_ClientState"
                                           name="dlistAvailableWorkers_ctl00_rg_WorkerExperience_ClientState"
                                           type="hidden" autocomplete="off"></div>
                            </div>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">العودة</button>
                <button type="button" class="btn btn-primary">تأكيد</button>
            </div>
        </div>
    </div>
</div>-->