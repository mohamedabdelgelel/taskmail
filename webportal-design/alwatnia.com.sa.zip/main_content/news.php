<!-- Inne Page Banner Area Start Here -->
<section class="inner-page-banner bg-common" data-bg-image="img/figure/breadcumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs-area">
                    <h1>الاخبار</h1>
                    <ul>
                        <li>
                            <a href="#">الرئيسية</a>
                        </li>
                        <li>الاخبار</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Inne Page Banner Area End Here -->
<!-- Blog Area Start Here -->
<section class="section-padding-2-10">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 news">
                <div class="row">
                    <div class="col-md-4 col-12">
                        <div class="blog-box-layout1">
                            <div class="item-img">
                                <a href="#"><img src="img/blog/blog6.jpg" alt="thumb"></a>
                            </div>
                            <div class="item-content">
                                 <h3 class="item-title"><a href="#">عنوان الخبر</a></h3>

                                <p>محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا </p>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-12">
                        <div class="blog-box-layout1">
                            <div class="item-img">
                                <a href="#"><img src="img/blog/blog6.jpg" alt="thumb"></a>
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="#">عنوان الخبر</a></h3>

                                <p>محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا </p>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-12">
                        <div class="blog-box-layout1">
                            <div class="item-img">
                                <a href="#"><img src="img/blog/blog6.jpg" alt="thumb"></a>
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="#">عنوان الخبر</a></h3>

                                <p>محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا محتوي الخبر هنا </p>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</section>
<!-- Blog Area End Here -->

