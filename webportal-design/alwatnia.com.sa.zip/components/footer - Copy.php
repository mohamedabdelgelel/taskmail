<!-- Footer Area Start Here -->
<footer class="footer-wrap-layout1 section-shape1">
    <div class="container">
        <div class="footer-bottom-box">
            <div class="row">
                <div class="col-md-6">
                    <div class="copyright">ﺟﻤﻴﻊ ﺍﻟﺤﻘﻮﻕ ﻣﺤﻔﻮﻇﺔ © للشركة الوطنية الاولى   </div>
                </div>
                <div class="col-md-6">
                    <div class="footer-bottom-menu">
                        <ul>
                            <li><a href="#">خريطة الموقع</a></li>
                            <li><a href="#">شروط الاستخدام</a></li>
                            <li><a href="#">سياسة الخصوصية</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End Here -->
<!-- Offcanvas Menu Start -->
<!-- Offcanvas Menu End -->
</div>
<!-- jquery-->
<script src="js/jquery-3.3.1.min.js"></script>
<!-- Plugins js -->
<script src="js/plugins.js"></script>
<!-- Popper js -->
<script src="js/popper.min.js"></script>
<!-- Bootstrap js -->
<script src="js/bootstrap.min.js"></script>
<!-- MeanMenu js -->
<script src="js/jquery.meanmenu.min.js"></script>
<!-- Nivo Slider js -->
<script src="vendor/slider/js/jquery.nivo.slider.js"></script>
<script src="vendor/slider/home.js"></script>
<!-- Owl Carousel js -->
<script src="vendor/OwlCarousel/owl.carousel.min.js"></script>
<!-- Magnific Popup js -->
<script src="js/jquery.magnific-popup.min.js"></script>
<!-- CounterUp js -->
<script src="js/jquery.counterup.min.js"></script>
<!-- WayPoints js -->
<script src="js/waypoints.min.js"></script>

<!-- Select 2 js -->
<script src="js/select2.min.js"></script>
<!-- Datetime Picker js -->
<script src="js/jquery.datetimepicker.full.min.js"></script>
<!-- Validator js -->
<script src="js/validator.min.js"></script>
<script src="js/custom-file-input.js"></script>
<!-- Main js -->
<script src="js/main_rtl.js"></script>
