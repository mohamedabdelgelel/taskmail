<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>الشركة الوطنية الأولى للخدمات المنزلية</title>
<meta name="description" content="الوطنية الأولى للخدمات المنزلية">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
<!-- Normalize CSS -->
<link rel="stylesheet" href="css/normalize.css">
<!-- Main CSS -->
<link rel="stylesheet" href="css/main.css">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap-rtl.css">
<!-- MeanMenu CSS -->
<link rel="stylesheet" href="css/meanmenu.min.css">
<!-- Font Awesome CSS -->
<link rel="stylesheet" href="css/fontawesome-all.min.css">
<!-- Animate CSS -->
<link rel="stylesheet" href="css/animate.min.css">
<!-- FlatIcon CSS -->
<link rel="stylesheet" href="font/flaticon.css">
<!-- Magnific Popup CSS -->
<link rel="stylesheet" href="css/magnific-popup.css">
<!-- Nivo Slider CSS -->
<link rel="stylesheet" href="vendor/slider/css/nivo-slider.css">
<!-- Owl Carousel CSS -->
<link rel="stylesheet" href="vendor/OwlCarousel/owl.carousel.min.css">
<link rel="stylesheet" href="vendor/OwlCarousel/owl.theme.default.min.css">

<!-- Select 2 CSS -->
<link rel="stylesheet" href="css/select2.min.css">
<link rel="stylesheet" href="css/component.css">
<!-- Datetime Picker CSS -->
<link rel="stylesheet" href="css/jquery.datetimepicker.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="css/style_ar.css">
<!-- Modernize js -->
<script src="js/modernizr-3.7.1.min.js"></script>